//
// Mobile button animation trigger
//
$(".mob-btn").click(function() {
  $(this).toggleClass("change");
  $("nav ul").toggleClass("open-menu");
});

//
// Cart Array
//
var cart = [];
if (!sessionStorage.cartSession) {
  cart = [];
} else {
  cart = JSON.parse(sessionStorage.cartSession);
}

//
// Generate Products into Page
//
$.each(productList, function(i, val) {
  $(".products").append(
    "<li><p>" +
      val.name +
      "</p><img src='" +
      val.img +
      "' height='200px'><span>Price: CDN$ " +
      val.price.toFixed(2) +
      "</span><button id='" +
      i +
      "' class='button-cta dark'>Add to Cart</button></li>"
  );
});

//
// "Add to Cart" button behaviour
//
$.each(productList, function(i, val) {
  $("#" + i).click(function() {
    if (!sessionStorage.cartSession) {
      cart = [];
    } else {
      cart = JSON.parse(sessionStorage.cartSession);
    }

    cart.push(val);
    sessionStorage.setItem("cartSession", JSON.stringify(cart));
    $(".cart-icon").attr(
      "data-before",
      JSON.parse(sessionStorage.getItem("cartSession")).length
    );
  });
});
