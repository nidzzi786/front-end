//
// Mobile responsiveness checking
//
$(window).scroll(function () {
    if ($(window).width() > 768) {
        if ($(window).scrollTop() == 0) {
            $("nav").css("background-color", "transparent");
            $("nav").css("position", "absolute");
            $("nav").css("height", "80px");
            $(".logo-nav").attr("src", "./img/logo_light.svg");
            $("nav ul li.active").css("filter", "grayscale(0)");
            $("nav ul li.active").css("filter", "brightness(100%)");
        } else {
            $("nav").css("background-color", "black");
            $("nav").css("position", "fixed");
            $("nav").css("height", "90px");
            $(".logo-nav").attr("src", "./img/logo_mono.svg");
            $("nav ul li.active").css("filter", "grayscale(100%)");
            $("nav ul li.active").css("filter", "brightness(500%)");
        }
    } else {
        $("nav").css("background-color", "black");
        $(".logo-nav").attr("src", "./img/logo_mono.svg");
    }
});

$(window).on("resize", function () {
    if ($(window).width() > 768) {
        if ($(window).scrollTop() == 0) {
            $("nav").css("background-color", "transparent");
            $("nav").css("position", "absolute");
            $("nav").css("height", "80px");
            $(".logo-nav").attr("src", "./img/logo_light.svg");
            $("nav ul li.active:before").css("filter", "grayscale(0)");
            $("nav ul li.active").css("filter", "grayscale(0)");
            $("nav ul li.active").css("filter", "brightness(100%)");
        } else {
            $("nav").css("background-color", "black");
            $("nav").css("position", "fixed");
            $("nav").css("height", "90px");
            $(".logo-nav").attr("src", "./img/logo_mono.svg");
            $("nav ul li.active:before").css("filter", "grayscale(100%)");
            $("nav ul li.active").css("filter", "grayscale(100%)");
            $("nav ul li.active").css("filter", "brightness(500%)");
        }
    } else {
        $("nav").css("background-color", "black");
        $(".logo-nav").attr("src", "./img/logo_mono.svg");
    }
});

if ($(window).width() < 768) {
    $("nav").css("background-color", "black");
}

//
// Mobile button animation trigger
//
$(".mob-btn").click(function () {
    $(this).toggleClass("change");
    $("nav ul").toggleClass("open-menu");
});
