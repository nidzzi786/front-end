function validateFormOnSubmit(purchase_form) {
    alert("Purchase complete!");

}

sessionStorage.removeItem("cartSession");
sessionStorage.removeItem("tax");
