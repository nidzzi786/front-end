//
// Mobile responsiveness checking
//
$(".wrapper").scroll(function() {
  if ($(window).width() > 768) {
    if ($(".wrapper").scrollTop() == 0) {
      $("nav").css("background-color", "transparent");
      $("nav").css("position", "absolute");
      $("nav").css("height", "80px");
      $(".logo-nav").attr("src", "./img/logo_light.svg");
      $(".modal-open").removeClass("mono");
      $("nav ul li.active").css("filter", "grayscale(0)");
      $("nav ul li.active").css("filter", "brightness(100%)");
    } else {
      $("nav").css("background-color", "#e1bc59");
      $("nav").css("position", "fixed");
      $("nav").css("height", "90px");
      $(".logo-nav").attr("src", "./img/logo_mono.svg");
      $(".modal-open").addClass("mono");
      $("nav ul li.active").css("filter", "grayscale(100%)");
      $("nav ul li.active").css("filter", "brightness(500%)");
    }
  } else {
    $("nav").css("background-color", "#e1bc59");
    $(".logo-nav").attr("src", "./img/logo_mono.svg");
    $(".modal-open").addClass("mono");
  }
});

$(window).on("resize", function() {
  if ($(window).width() > 768) {
    if ($(".wrapper").scrollTop() == 0) {
      $("nav").css("background-color", "transparent");
      $("nav").css("position", "absolute");
      $("nav").css("height", "80px");
      $(".logo-nav").attr("src", "./img/logo_light.svg");
      $(".modal-open").removeClass("mono");
      $("nav ul li.active:before").css("filter", "grayscale(0)");
      $("nav ul li.active").css("filter", "grayscale(0)");
      $("nav ul li.active").css("filter", "brightness(100%)");
    } else {
      $("nav").css("background-color", "#e1bc59");
      $("nav").css("position", "fixed");
      $("nav").css("height", "90px");
      $(".logo-nav").attr("src", "./img/logo_mono.svg");
      $(".modal-open").addClass("mono");
      $("nav ul li.active:before").css("filter", "grayscale(100%)");
      $("nav ul li.active").css("filter", "grayscale(100%)");
      $("nav ul li.active").css("filter", "brightness(500%)");
    }
  } else {
    $("nav").css("background-color", "#e1bc59");
    $(".logo-nav").attr("src", "./img/logo_mono.svg");
    $(".modal-open").addClass("mono");
  }
});

if ($(window).width() < 768) {
  $("nav").css("background-color", "#e1bc59");
  $(".logo-nav").attr("src", "./img/logo_mono.svg");
  $(".modal-open").addClass("mono");
}

//
// Mobile button animation trigger
//
$(".mob-btn").click(function() {
  $(this).toggleClass("change");
  $("nav ul").toggleClass("open-menu");
});

//
// Modal handler
//
$(".modal-open").click(function() {
  $("body").css("overflow", "hidden");
  $("#modal").css("display", "flex");
});

$(".modal-close").click(function() {
  $("body").css("overflow", "initial");
  $("#modal").css("display", "none");
});
