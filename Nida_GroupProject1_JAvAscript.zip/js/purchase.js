//
// Page & Scripts made by Andrea
//
//

function validateFormOnSubmit(purchase_form) {
  alert("Purchase complete!");
}

$(function() {
  // TotalAmount
  var totalAmount = 0.0;
  var total = 0.0;

  // Displays expected format for each property
  document.getElementById("fname").placeholder = "FirstName LastName";
  document.getElementById("email").placeholder = "email@example.com";
  document.getElementById("adr").placeholder = "Address";
  document.getElementById("city").placeholder = "City";
  document.getElementById("state").placeholder = "State";
  document.getElementById("zip").placeholder = "A1A 1A1";
  //   $('#zip').mask("[A-Za-z][0-9][A-Za-z] [0-9][A-Za-z][0-9]", {placeholder: "A1A 1A1"});
  document.getElementById("cname").placeholder = "Name";
  document.getElementById("ccnum").placeholder = "1111-2222-3333-4444";
  document.getElementById("expmonth").placeholder = "Month";
  document.getElementById("expyear").placeholder = "YYYY";
  document.getElementById("cvv").placeholder = "NNN";

  //JQuery Mask
  $("#zip").mask("ZZZ ZZZ", {
    translation: {
      Z: {
        pattern: /[0-9a-zA-Z]/,
        optional: true
      }
    }
  });
  $("#ccnum").mask("0000-0000-0000-0000");
  $("#expmonth").mask("00");
  $("#expyear").mask("0000");
  $("#cvv").mask("000");

  // Field or Property valdiation
  $("form[name='purchase_form']").validate({
    rules: {
      fname: {
        required: true
      },
      email: {
        required: true,
        email: true
      },
      address: {
        required: true
      },
      city: {
        required: true
      },
      state: {
        required: true
      },
      zip: {
        required: true
        //            pattern: [A-Za-z][0-9][A-Za-z] [0-9][A-Za-z][0-9]
      },
      cardname: {
        required: true
      },
      cardnumber: {
        required: true,
        creditcard: true
      },
      expmonth: {
        required: true,
        range: [1, 12]
      },
      expyear: {
        required: true,
        digits: true,
        date: true,
        minlength: 4,
        maxlength: 4,
        range: [2019, 9999]
      },
      cvv: {
        required: true,
        digits: true,
        minlength: 3,
        maxlength: 3
      }
    },
    messages: {
      fname: "Please enter full name",
      email: "Please enter a valid email address",
      address: "Please enter address",
      city: "Please enter city",
      zip: "Enter valid zip code",
      cardname: "Please enter name",
      cardnumber: "Please enter a valid format",
      expmonth: "Enter a valid month",
      expyear: "Enter a valid year",
      cvv: "Please enter number"
    }
  });

  //
  // Group Cart Items
  // this will help to get items from cart
  //
  var purchaseorder = _.groupBy(
    JSON.parse(sessionStorage.getItem("cartSession")),
    function(val) {
      return val.name;
    }
  );

  //
  // Get tax value from storage
  //
  var purchasetax = JSON.parse(sessionStorage.getItem("taxSession"));
  console.log(purchasetax[0].tax);

  //
  // This will append stored elements and data
  //
  var prodtotal = 0.0;
  var totalTaxAmount = 0.0;
  $.each(purchaseorder, function(i, val) {
    // Get sub-total amount for EACH item (Item price x qty)
    var productSubtotal = val[0].price.toFixed(2) * val.length;

    // Get total cost of all items plus tax amount
    totalTaxAmount = totalTaxAmount + productSubtotal * purchasetax;

    // Displays Item with quantity and sub total amount
    $(".purchasecart").append(
      "<li>" +
        val[0].name +
        " (" +
        val.length +
        ") " +
        "CDN$ " +
        productSubtotal.toFixed(2) +
        "</li>"
    );

    // Get total amount for ALL item
    prodtotal = prodtotal + productSubtotal;

    // Resets the value for each item
    productSubtotal = 0.0;
  });

  // Displays Summary Subtotal
  $(".purchasesubtotal").html(prodtotal.toFixed(2));

  // Displays Summary Tax
  $(".purchasetax").html(purchasetax[0].tax);

  // Displays Summary of total ampount to pay including tax value
  $(".purchasetotal").html(
    parseInt(prodtotal.toFixed(2)) +
      parseInt(prodtotal.toFixed(2)) * purchasetax[0].tax
  );
});
