//
// Page & Scripts made by Gustavo
//
//
// Tax API integration by Nida
//

//
// Product List
//
var productList = {
  jacket1: {
    name: "Jacket #1",
    price: 150.0,
    img: "./img/jacket1.png"
  },
  jacket2: {
    name: "Jacket #2",
    price: 80.2,
    img: "./img/jacket2.png"
  },
  jacket3: {
    name: "Jacket #3",
    price: 79.99,
    img: "./img/jacket3.png"
  },
  jacket4: {
    name: "Jacket #4",
    price: 112.5,
    img: "./img/jacket4.png"
  },
  jacket5: {
    name: "Jacket #5",
    price: 50.1,
    img: "./img/jacket5.png"
  }
  //   jacket6: {
  //     name: "Jacket #6",
  //     price: 999.99,
  //     img: "./img/jacket2.png"
  //   }
};

//
// Update Cart Badge Number
//
if (!JSON.parse(sessionStorage.getItem("cartSession"))) {
  $(".cart-icon").attr("data-before", "0");
} else {
  $(".cart-icon").attr(
    "data-before",
    JSON.parse(sessionStorage.getItem("cartSession")).length
  );
}

//
// Modal
//
$(".popup").click(function() {
  //
  // Group Cart Items
  // this will help to add/remove items from cart
  //
  var order = _.groupBy(
    JSON.parse(sessionStorage.getItem("cartSession")),
    function(val) {
      return val.name;
    }
  );

  //
  // Open modal and clear content since we're appending HTML later on
  //
  $("#myModal").modal();
  $(".cart").html("");

  //
  // This will append stored elements and data into cart modal
  //
  $.each(order, function(i, val) {
    $(".cart").append(
      "<li><img src='" +
        val[0].img +
        "' height='140px' width='105px'><div class='desc'><p>" +
        val[0].name +
        "</p><span>CDN$ " +
        val[0].price.toFixed(2) +
        "</span><div class='controls'><button class='rem'>-</button><strong>" +
        val.length +
        "</strong><button class='add'>+</button></div></div></li>"
    );
  });

  //
  // Show subtotal
  //
  var subtotal = _.sumBy(
    JSON.parse(sessionStorage.getItem("cartSession")),
    function(val) {
      return val.price;
    }
  );

  //
  // Ajax Call to call api and calculate the tax
  //
  var tax;
  var total;

  $.ajax({
    url:
      "https://cors-anywhere.herokuapp.com/https://api.salestaxapi.ca/v2/province/on",
    type: "GET",
    headers: {
      "Access-Control-Allow-Credentials": true,
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET",
      "Access-Control-Allow-Headers": "application/json"
    },
    //Loader Show
    beforeSend: function() {
      // Show image container
      console.log("show loader");
      $("#loader").show();
    },
    //On Success
    success: function(data) {
      console.log(JSON.stringify(data));
      tax = data.applicable;
      console.log(tax);
      $(".subtotal").html(
        "<strong>Subtotal: </strong> CDN$: " + subtotal.toFixed(2)
      );
      $(".tax").html("<strong>TAX: </strong> GST: " + tax);
      total = parseInt(subtotal) + parseInt(subtotal) * tax;
      $(".total").html("<strong>Total: </strong> CDN$: " + total.toFixed(2));

      //Store tax data on sessionstorage
      var taxSession = [{ tax: tax }];
      sessionStorage.setItem("taxSession", JSON.stringify(taxSession));
    },
    //Hide Loader
    complete: function(data) {
      console.log("Hide Loader");
      $("#loader").hide();
    }
  });

  //
  // Remove items button behaviour
  //
  $("button.rem").click(function() {
    var cartUpdate = JSON.parse(sessionStorage.getItem("cartSession"));

    // If there's more than 1 item AND it is not 1
    if (
      $(this)
        .siblings("strong")
        .html() > 0 &&
      $(this)
        .siblings("strong")
        .html() != 1
    ) {
      // Then, remove 1 item
      $(this)
        .siblings("strong")
        .html(
          parseInt(
            $(this)
              .siblings("strong")
              .html()
          ) - 1
        );

      // https://stackoverflow.com/questions/48177062/javascript-lodash-removing-an-item-from-an-array-has-the-same-id
      var index = _.findIndex(cartUpdate, {
        name: $(this)
          .parent()
          .parent()
          .children("p")
          .html()
      });
      cartUpdate.splice(index, 1);

      sessionStorage.setItem("cartSession", JSON.stringify(cartUpdate));

      $(".cart-icon").attr(
        "data-before",
        JSON.parse(sessionStorage.getItem("cartSession")).length
      );

      subtotal = _.sumBy(
        JSON.parse(sessionStorage.getItem("cartSession")),
        function(val) {
          return val.price;
        }
      );
      // Update Total, SubTotal
      $(".subtotal").html(
        "<strong>Subtotal: </strong> CDN$: " + subtotal.toFixed(2)
      );
      $(".tax").html("<strong>TAX: </strong> GST: " + tax);
      total = parseInt(subtotal) + parseInt(subtotal) * tax;
      $(".total").html("<strong>Total: </strong> CDN$: " + total.toFixed(2));
    }

    // If there's only 1 item
    else if (
      $(this)
        .siblings("strong")
        .html() == 1
    ) {
      // Then, remove 1 item AND turn opacity down
      $(this)
        .siblings("strong")
        .html(
          parseInt(
            $(this)
              .siblings("strong")
              .html()
          ) - 1
        );

      var index = _.findIndex(cartUpdate, {
        name: $(this)
          .parent()
          .parent()
          .children("p")
          .html()
      });
      cartUpdate.splice(index, 1);

      sessionStorage.setItem("cartSession", JSON.stringify(cartUpdate));

      $(this)
        .parent()
        .parent()
        .parent()
        .css("opacity", ".5");
      $(this).attr("disabled", true);

      $(".cart-icon").attr(
        "data-before",
        JSON.parse(sessionStorage.getItem("cartSession")).length
      );

      subtotal = _.sumBy(
        JSON.parse(sessionStorage.getItem("cartSession")),
        function(val) {
          return val.price;
        }
      );
      // Update Total, SubTotal
      $(".subtotal").html(
        "<strong>Subtotal: </strong> CDN$: " + subtotal.toFixed(2)
      );
      $(".tax").html("<strong>TAX: </strong> GST: " + tax);
      total = parseInt(subtotal) + parseInt(subtotal) * tax;
      $(".total").html("<strong>Total: </strong> CDN$: " + total.toFixed(2));
    }
  });

  $("button.add").click(function() {
    var cartUpdate = JSON.parse(sessionStorage.getItem("cartSession"));
    cartUnique = _.uniqBy(cartUpdate, "name");

    // If there's no item
    if (
      $(this)
        .siblings("strong")
        .html() == 0
    ) {
      // Then, add 1 item AND turn opacity up
      $(this)
        .siblings("strong")
        .html(
          parseInt(
            $(this)
              .siblings("strong")
              .html()
          ) + 1
        );

      var productName = $(this)
        .parent()
        .parent()
        .children("p")
        .html();
      var productAdd = _.find(productList, ["name", productName]);

      cartUpdate.push(productAdd);
      sessionStorage.setItem("cartSession", JSON.stringify(cartUpdate));

      $(this)
        .parent()
        .parent()
        .parent()
        .css("opacity", "1");
      $(this)
        .siblings(".rem")
        .removeAttr("disabled");

      $(".cart-icon").attr(
        "data-before",
        JSON.parse(sessionStorage.getItem("cartSession")).length
      );

      subtotal = _.sumBy(
        JSON.parse(sessionStorage.getItem("cartSession")),
        function(val) {
          return val.price;
        }
      );
      $(".subtotal").html(
        "<strong>Subtotal: </strong> CDN$: " + subtotal.toFixed(2)
      );
      $(".tax").html("<strong>TAX: </strong> GST: " + tax);
      total = parseInt(subtotal) + parseInt(subtotal) * tax;
      $(".total").html("<strong>Total: </strong> CDN$: " + total.toFixed(2));
    }

    // If there's more than 1 item
    else if (
      $(this)
        .siblings("strong")
        .html() >= 1
    ) {
      // Then, add 1 item
      $(this)
        .siblings("strong")
        .html(
          parseInt(
            $(this)
              .siblings("strong")
              .html()
          ) + 1
        );

      var productName = $(this)
        .parent()
        .parent()
        .children("p")
        .html();
      $.each(cartUnique, function(i, val) {
        $(this).hide();
        if (cartUnique[i].name == productName) {
          cartUpdate.push(val);
        }
      });

      sessionStorage.setItem("cartSession", JSON.stringify(cartUpdate));

      $(".cart-icon").attr(
        "data-before",
        JSON.parse(sessionStorage.getItem("cartSession")).length
      );

      subtotal = _.sumBy(
        JSON.parse(sessionStorage.getItem("cartSession")),
        function(val) {
          return val.price;
        }
      );
      $(".subtotal").html(
        "<strong>Subtotal: </strong> CDN$: " + subtotal.toFixed(2)
      );
      $(".tax").html("<strong>TAX: </strong> GST: " + tax);
      total = parseInt(subtotal) + parseInt(subtotal) * tax;
      $(".total").html("<strong>Total: </strong> CDN$: " + total.toFixed(2));
    }
  });
});
